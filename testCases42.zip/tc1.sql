SELECT n.n_nationkey
FROM nation AS n 
WHERE (n.n_name = 'UNITED STATES')
